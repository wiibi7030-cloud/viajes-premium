'use client'

import { useState } from 'react'
import {
  ArrowRight,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  Globe2,
  Hotel,
  MapPin,
  Plane,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Ticket,
  Users,
} from 'lucide-react'

const heroImage = '/wanderlust-hero.png'
const atelierLogo = '/atelier-logo.png'

const destinations = [
  { name: 'Cancún', country: 'México', tag: 'Playas y sol', iata: 'CUN', image: 'https://images.unsplash.com/photo-1552074284-5e88ef1aef18?auto=format&fit=crop&w=900&q=85', price: 'Desde $2,490 MXN' },
  { name: 'Santorini', country: 'Grecia', tag: 'Escapada romántica', iata: 'JTR', image: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=900&q=85', price: 'Desde $14,800 MXN' },
  { name: 'Bali', country: 'Indonesia', tag: 'Aventura tropical', iata: 'DPS', image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=900&q=85', price: 'Desde $18,900 MXN' },
  { name: 'París', country: 'Francia', tag: 'Arte y cultura', iata: 'CDG', image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=85', price: 'Desde $16,900 MXN' },
  { name: 'Nueva York', country: 'Estados Unidos', tag: 'Ciudad vibrante', iata: 'JFK', image: 'https://images.unsplash.com/photo-1496588152823-86ff7695e68f?auto=format&fit=crop&w=900&q=85', price: 'Desde $7,800 MXN' },
  { name: 'Londres', country: 'Reino Unido', tag: 'Historia y estilo', iata: 'LHR', image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=900&q=85', price: 'Desde $18,400 MXN' },
  { name: 'Tokio', country: 'Japón', tag: 'Futuro y tradición', iata: 'NRT', image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=900&q=85', price: 'Desde $22,900 MXN' },
  { name: 'Dubái', country: 'Emiratos Árabes', tag: 'Lujo y desierto', iata: 'DXB', image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=85', price: 'Desde $21,800 MXN' },
  { name: 'Roma', country: 'Italia', tag: 'Historia viva', iata: 'FCO', image: 'https://images.unsplash.com/photo-1529260830199-42c24126f198?auto=format&fit=crop&w=900&q=85', price: 'Desde $15,600 MXN' },
  { name: 'Lisboa', country: 'Portugal', tag: 'Encanto europeo', iata: 'LIS', image: 'https://images.unsplash.com/photo-1555881400-74d7acaacd8b?auto=format&fit=crop&w=900&q=85', price: 'Desde $14,900 MXN' },
  { name: 'Marrakech', country: 'Marruecos', tag: 'Colores y sabores', iata: 'RAK', image: 'https://images.unsplash.com/photo-1597212618440-806262de4f6b?auto=format&fit=crop&w=900&q=85', price: 'Desde $19,700 MXN' },
  { name: 'Sídney', country: 'Australia', tag: 'Costa y aventura', iata: 'SYD', image: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d7?auto=format&fit=crop&w=900&q=85', price: 'Desde $25,900 MXN' },
  { name: 'Reikiavik', country: 'Islandia', tag: 'Naturaleza extrema', iata: 'KEF', image: 'https://images.unsplash.com/photo-1520769945061-0a448c463865?auto=format&fit=crop&w=900&q=85', price: 'Desde $20,400 MXN' },
  { name: 'Cartagena', country: 'Colombia', tag: 'Caribe colonial', iata: 'CTG', image: 'https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?auto=format&fit=crop&w=900&q=85', price: 'Desde $4,900 MXN' },
  { name: 'Oaxaca', country: 'México', tag: 'Cultura y gastronomía', iata: 'OAX', image: 'https://images.unsplash.com/photo-1512813195386-6cf811f2b4f3?auto=format&fit=crop&w=900&q=85', price: 'Desde $2,900 MXN' },
]

const flights = [
  { airline: 'Aero México', code: 'AM 584', from: 'CDMX', to: 'CUN', time: '08:35 — 10:48', duration: '2h 13m', price: '$2,490', color: 'bg-[#dff2ed]' },
  { airline: 'Volaris', code: 'Y4 712', from: 'CDMX', to: 'CUN', time: '12:20 — 14:34', duration: '2h 14m', price: '$2,180', color: 'bg-[#eef0fa]' },
  { airline: 'Viva Aerobus', code: 'VB 1012', from: 'CDMX', to: 'CUN', time: '18:05 — 20:19', duration: '2h 14m', price: '$1,960', color: 'bg-[#f7ede5]' },
]

export default function Page() {
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [selectedDestination, setSelectedDestination] = useState('Cancún')
  const [flightSearch, setFlightSearch] = useState(false)
  const [showAllDestinations, setShowAllDestinations] = useState(false)

  const chooseDestination = (name: string) => {
    setSelectedDestination(name)
    setSearchOpen(false)
    const destination = destinations.find((item) => item.name === name)
    if (destination) window.open(`https://www.klook.com/es/search/?query=${encodeURIComponent(`${destination.name}, ${destination.country}`)}`, '_blank', 'noopener,noreferrer')
  }

  const submitSearch = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setFlightSearch(true)
    const destination = destinations.find((item) => item.name === selectedDestination)
    const destinationCode = destination?.iata ?? selectedDestination
    const aviasalesUrl = `https://www.aviasales.com/search?origin=MEX&destination=${encodeURIComponent(destinationCode)}`
    window.open(aviasalesUrl, '_blank', 'noopener,noreferrer')
    document.getElementById('recommended-flights')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#f6f2e9] text-[#3d3427]">
      <section className="relative min-h-[720px] overflow-hidden bg-[#123c47] text-white lg:min-h-[790px]">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroImage})` }} />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(6,34,42,.88)_0%,rgba(10,45,52,.58)_46%,rgba(9,35,42,.13)_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(4,26,31,.38)_0%,transparent_35%,rgba(4,26,31,.36)_100%)]" />

        <header className="relative z-10 mx-auto flex max-w-[1250px] items-center justify-between px-6 py-6 lg:px-10">
          <a href="#top" className="flex items-center gap-3" aria-label="ATELIER inicio">
            <div className="relative flex h-14 w-[190px] items-center overflow-hidden rounded-md bg-[#071f25]/90 px-2 shadow-lg ring-1 ring-[#c5a46d]/30">
              <img src={atelierLogo} alt="ATELIER · Travel Atelier · Curated Journeys" className="size-full scale-[1.65] object-contain" />
            </div>
          </a>
          <nav className="hidden items-center gap-9 text-[13px] text-white/80 lg:flex">
            <a href="#destinations" className="transition hover:text-white">Destinos <ChevronDown className="ml-1 inline" size={13} /></a>
            <a href="#experiences" className="transition hover:text-white">Experiencias <ChevronDown className="ml-1 inline" size={13} /></a>
            <a href="#recommended-flights" className="transition hover:text-white">Vuelos</a>
            <a href="#about" className="transition hover:text-white">Nosotros</a>
          </nav>
          <div className="flex items-center gap-3">
            <button aria-label="Buscar destinos" onClick={() => setSearchOpen((open) => !open)} className="flex size-10 items-center justify-center rounded-full border border-white/20 bg-white/10 backdrop-blur transition hover:bg-white/20"><Search size={17} /></button>
            <button className="hidden items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-xs sm:flex"><Globe2 size={14} /> ES <ChevronDown size={12} /></button>
            <a href="#flight-planner" className="hidden rounded-full bg-[#6addc8] px-5 py-3 text-xs font-bold text-[#123c47] transition hover:-translate-y-0.5 hover:bg-[#8bf0dd] sm:block">Planifica tu viaje <ArrowRight className="ml-2 inline" size={14} /></a>
          </div>
        </header>

        {searchOpen && <div className="absolute right-6 top-20 z-30 w-[min(360px,calc(100%-3rem))] rounded-2xl border border-white/20 bg-[#123c47]/95 p-4 shadow-2xl backdrop-blur-xl lg:right-10"><div className="mb-3 text-xs font-semibold uppercase tracking-[.18em] text-white/50">Buscar destino</div><div className="flex items-center gap-2 rounded-xl bg-white/10 px-3"><Search size={16} className="text-[#c5a46d]" /><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Ej. Cancún" className="w-full bg-transparent py-3 text-sm outline-none placeholder:text-white/40" /></div><div className="mt-3 flex flex-col gap-1">{destinations.filter((destination) => destination.name.toLowerCase().includes(query.toLowerCase())).map((destination) => <button key={destination.name} onClick={() => chooseDestination(destination.name)} className="flex items-center gap-3 rounded-xl px-2 py-2 text-left text-sm transition hover:bg-white/10"><MapPin size={15} className="text-[#c5a46d]" /> {destination.name}, {destination.country}</button>)}</div></div>}

        <div className="relative z-10 mx-auto flex max-w-[1250px] flex-col justify-center px-6 pb-16 pt-24 lg:min-h-[580px] lg:px-10 lg:pb-20 lg:pt-28">
          <div className="max-w-[600px] animate-[fadeUp_.8s_ease-out_both]"><div className="mb-5 flex items-center gap-3 text-xs font-semibold uppercase tracking-[.25em] text-[#d6b97a]"><span className="h-px w-9 bg-[#d6b97a]" /> El mundo te espera</div><h1 className="font-serif text-[clamp(3.3rem,7vw,6.4rem)] leading-[.92] tracking-[-.04em]">Viajes que<br /><em className="font-normal text-[#77e4d2]">se quedan</em><br />contigo.</h1><p className="mt-7 max-w-[440px] text-base leading-7 text-white/75">Encuentra destinos extraordinarios, vuelos inteligentes y experiencias que transforman cada escapada.</p><div className="mt-8 flex flex-wrap gap-3"><a href="#destinations" className="rounded-full bg-[#c5a46d] px-6 py-3.5 text-sm font-bold text-[#123c47] transition hover:-translate-y-1">Explorar destinos <ArrowRight className="ml-2 inline" size={15} /></a><a href="#flight-planner" className="rounded-full border border-white/30 bg-white/10 px-6 py-3.5 text-sm font-medium backdrop-blur transition hover:bg-white/20">Planear mi viaje</a></div></div>
        </div>

        <div className="relative z-10 mx-auto max-w-[1250px] px-6 lg:px-10"><div className="grid gap-4 lg:grid-cols-[1.1fr_1fr_1fr]">{destinations.slice(0, 3).map((destination, index) => <button key={destination.name} onClick={() => chooseDestination(destination.name)} className={`group relative h-[170px] overflow-hidden rounded-2xl border border-white/20 text-left shadow-xl transition hover:-translate-y-2 ${index === 2 ? 'hidden lg:block' : ''}`}><img src={destination.image} alt={`${destination.name}, ${destination.country}`} className="absolute inset-0 size-full object-cover transition duration-700 group-hover:scale-110" /><div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" /><div className="absolute bottom-4 left-4"><div className="text-lg font-semibold">{destination.name}</div><div className="text-xs text-white/70">{destination.country} · {destination.price}</div></div><Star size={14} fill="currentColor" className="absolute bottom-5 right-4 text-[#ffd66c]" /></button>)}</div></div>
      </section>

      <section id="flight-planner" className="relative z-20 mx-auto -mt-7 max-w-[1120px] px-5 lg:-mt-10"><form onSubmit={submitSearch} className="hidden rounded-[26px] border border-white/80 bg-white/95 p-4 shadow-[0_25px_70px_rgba(18,60,71,.18)] backdrop-blur-xl md:p-5"><div className="mb-4 flex items-center justify-between"><div><div className="text-[11px] font-bold uppercase tracking-[.18em] text-[#6d9a9d]">Buscador de vuelos</div><div className="mt-1 font-serif text-2xl text-[#3d3427]">¿A dónde quieres escapar?</div></div><div className="flex items-center gap-2 rounded-full bg-[#edf8f5] px-3 py-2 text-xs font-semibold text-[#2d8e80]"><Sparkles size={14} /> Precios flexibles <span className="hidden text-[#8aa3a3] sm:inline">· Aviasales</span></div></div><div className="grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1fr_auto]"><label className="rounded-2xl border border-[#dfe9e7] bg-[#fbfdfc] p-3"><span className="block text-[10px] font-bold uppercase tracking-[.14em] text-[#8aa3a3]">Origen</span><span className="mt-1 flex items-center gap-2"><Plane size={15} className="text-[#55bdaa]" /><input defaultValue="Ciudad de México (MEX)" className="w-full bg-transparent text-sm font-medium outline-none" aria-label="Origen" /></span></label><label className="rounded-2xl border border-[#b8e7de] bg-[#edf9f6] p-3"><span className="block text-[10px] font-bold uppercase tracking-[.14em] text-[#55a59b]">Destino</span><span className="mt-1 flex items-center gap-2"><MapPin size={15} className="text-[#35a994]" /><input value={selectedDestination} onChange={(e) => setSelectedDestination(e.target.value)} className="w-full bg-transparent text-sm font-semibold outline-none" aria-label="Destino" /></span></label><label className="rounded-2xl border border-[#dfe9e7] bg-[#fbfdfc] p-3"><span className="block text-[10px] font-bold uppercase tracking-[.14em] text-[#8aa3a3]">Fechas</span><span className="mt-1 flex items-center gap-2 text-sm font-medium"><CalendarDays size={15} className="text-[#55bdaa]" /><input type="text" value="20 May" readOnly aria-label="Fecha de salida" className="min-w-0 flex-1 bg-transparent text-sm font-medium text-[#3d3427] outline-none" /><span className="text-[#9ab3b1]">—</span><input type="text" value="30 May" readOnly aria-label="Fecha de regreso" className="min-w-0 flex-1 bg-transparent text-sm font-medium text-[#3d3427] outline-none" /> 20 May — 30 May</span></label><label className="rounded-2xl border border-[#dfe9e7] bg-[#fbfdfc] p-3"><span className="block text-[10px] font-bold uppercase tracking-[.14em] text-[#8aa3a3]">Viajeros</span><span className="mt-1 flex items-center gap-2 text-sm font-medium"><Users size={15} className="text-[#55bdaa]" /><select defaultValue="2" aria-label="Número de viajeros" className="w-full bg-transparent text-sm font-medium outline-none"><option value="1">1 Adulto</option><option value="2">2 Adultos</option><option value="3">3 Adultos</option><option value="4">4 Adultos</option><option value="5">5 Adultos</option><option value="6">6 Adultos</option></select> 2 Adultos</span></label><button className="rounded-2xl bg-[#173f49] px-6 py-3 text-sm font-bold text-white transition hover:bg-[#27606a]" type="submit"><Search className="mx-auto" size={19} /><span className="sr-only">Buscar vuelos</span></button></div></form><div className="overflow-hidden rounded-[26px] border border-[#dfe9e7] bg-white/95 p-3 shadow-[0_25px_70px_rgba(18,60,71,.18)] backdrop-blur-xl md:p-5" aria-label="Buscador de vuelos Aviasales"><iframe title="Buscador de vuelos y hoteles Aviasales" className="h-[285px] w-full border-0" srcDoc={'<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head><body style="margin:0;background:#fff"><script async src="https://tpembd.com/content?currency=usd&trs=581256&shmarker=785312&show_hotels=true&powered_by=true&locale=en&searchUrl=www.aviasales.com%2Fsearch&primary_override=%2332a8dd&color_button=%2332a8dd&color_icons=%2332a8dd&dark=%23262626&light=%23FFFFFF&secondary=%23FFFFFF&special=%23C4C4C4&color_focused=%2332a8dd&border_radius=0&no_labels=&plain=true&promo_id=7879&campaign_id=100" charset="utf-8"></script></body></html>'} /></div></section>

      <section id="destinations" className="mx-auto max-w-[1250px] px-6 py-20 lg:px-10"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><div className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#55bdaa]">Destinos curados</div><h2 className="font-serif text-4xl tracking-tight text-[#3d3427] md:text-5xl">Lugares para recordar</h2></div><button type="button" onClick={() => setShowAllDestinations((visible) => !visible)} className="text-sm font-semibold text-[#2d8e80] transition hover:text-[#1e6d63]">{showAllDestinations ? 'Mostrar menos' : 'Ver todos'} <ChevronRight className={`ml-1 inline transition-transform ${showAllDestinations ? 'rotate-90' : ''}`} size={16} /></button></div><div className="mt-10 grid gap-6 md:grid-cols-3">{(showAllDestinations ? destinations : destinations.slice(0, 3)).map((destination) => <button key={destination.name} onClick={() => chooseDestination(destination.name)} className="group text-left"><div className="relative aspect-[1.12] overflow-hidden rounded-[24px]"><img src={destination.image} alt={`${destination.name}, ${destination.country}`} className="size-full object-cover transition duration-700 group-hover:scale-105" /><div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" /><div className="absolute bottom-5 left-5 text-white"><div className="text-2xl font-semibold">{destination.name}</div><div className="text-sm text-white/75">{destination.country}</div></div><div className="absolute right-4 top-4 rounded-full bg-white/90 px-3 py-1 text-[11px] font-semibold text-[#3d3427]">{destination.tag}</div></div><div className="mt-4 flex items-center justify-between"><span className="text-sm text-[#6d8586]">{destination.price}</span><span className="flex items-center gap-1 text-sm font-semibold text-[#e29d5a]"><Star size={14} fill="currentColor" /> 4.9</span></div></button>)}</div></section>

      <section id="recommended-flights" className="bg-[#edf6f3] px-6 py-20 lg:px-10"><div className="mx-auto max-w-[1120px]"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><div className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#55bdaa]">{flightSearch ? 'Resultados de tu búsqueda' : 'Próximamente con API'}</div><h2 className="font-serif text-4xl tracking-tight text-[#3d3427] md:text-5xl">Vuelos a {selectedDestination}</h2><p className="mt-3 text-sm text-[#6d8586]">Las mejores opciones para comenzar tu siguiente aventura.</p></div><button className="flex items-center gap-2 text-sm font-semibold text-[#2d8e80]">Ordenar por precio <ChevronDown size={15} /></button></div><div className="mt-9 grid gap-4">{flights.map((flight) => <article key={flight.code} className="flex flex-col gap-5 rounded-3xl border border-white bg-white p-5 shadow-sm transition hover:shadow-lg md:flex-row md:items-center"><div className={`flex size-12 shrink-0 items-center justify-center rounded-2xl ${flight.color}`}><Plane size={20} className="text-[#2f6b72]" /></div><div className="min-w-[140px] flex-1"><div className="font-semibold text-[#3d3427]">{flight.airline}</div><div className="mt-1 text-xs text-[#8aa3a3]">{flight.code} · Directo</div></div><div className="flex items-center gap-5"><div><div className="font-semibold">{flight.from} <span className="mx-2 text-[#9ab3b1]">→</span> {flight.to}</div><div className="mt-1 text-xs text-[#8aa3a3]">{flight.time} · {flight.duration}</div></div></div><div className="flex items-center justify-between gap-6 md:ml-auto"><div><div className="text-[10px] uppercase tracking-wider text-[#8aa3a3]">Desde</div><div className="text-xl font-bold text-[#3d3427]">{flight.price}</div></div><button className="rounded-full border border-[#b8e7de] px-4 py-2 text-xs font-bold text-[#2d8e80] transition hover:bg-[#edf9f6]">Ver vuelo</button></div></article>)}</div><div className="mt-6 flex items-center justify-center gap-2 text-xs text-[#7d9998]"><Ticket size={14} /> Diseños de vuelos de muestra · Conectaremos la API en el siguiente paso</div></div></section>

      <section id="about" className="mx-auto grid max-w-[1250px] gap-6 px-6 py-16 sm:grid-cols-3 lg:px-10"><div className="flex gap-4 rounded-2xl border border-[#e0ebe8] bg-white p-5"><ShieldCheck className="shrink-0 text-[#55bdaa]" /><div><div className="font-semibold">Viajes seguros</div><p className="mt-1 text-xs leading-5 text-[#7d9998]">Opciones seleccionadas para viajar con tranquilidad.</p></div></div><div className="flex gap-4 rounded-2xl border border-[#e0ebe8] bg-white p-5"><Globe2 className="shrink-0 text-[#55bdaa]" /><div><div className="font-semibold">Ideas reales</div><p className="mt-1 text-xs leading-5 text-[#7d9998]">Inspiración de destinos para cada estilo de viaje.</p></div></div><div className="flex gap-4 rounded-2xl border border-[#e0ebe8] bg-white p-5"><Hotel className="shrink-0 text-[#55bdaa]" /><div><div className="font-semibold">Todo en un lugar</div><p className="mt-1 text-xs leading-5 text-[#7d9998]">Vuelos, hoteles y experiencias, próximamente.</p></div></div></section>

      <footer className="border-t border-[#e5dccb] bg-[#f3eee4] px-6 py-8 text-center text-xs text-[#8a7658]"><div className="mx-auto flex max-w-[1250px] flex-col items-center gap-3"><div className="flex h-24 w-56 items-center justify-center rounded-md bg-[#102f35] px-3 ring-1 ring-[#c5a46d]/30"><img src={atelierLogo} alt="ATELIER · Travel Atelier · Curated Journeys" className="size-full scale-[1.65] object-contain" /></div><p className="text-[10px] tracking-[.12em]">TRAVEL ATELIER · CURATED JOURNEYS</p><p className="text-[10px]">© 2026 ATELIER</p></div></footer>
    </main>
  )
}
